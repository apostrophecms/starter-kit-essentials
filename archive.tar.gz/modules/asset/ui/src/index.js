export default () => {
  // Your own project level JS may go here
  // eslint-disable-next-line no-console
  console.log('Hello World');
};
