export default {
  plugins: {
    autoprefixer: {}
  }
};
