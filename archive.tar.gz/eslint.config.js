import apostrophe from 'eslint-config-apostrophe';
import { defineConfig } from 'eslint/config';

export default defineConfig([
  apostrophe
]);
